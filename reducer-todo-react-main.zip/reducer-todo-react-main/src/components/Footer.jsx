import React from 'react'

function Footer() {
  return (
    <div className="footer">
      <p>&copy; 2024 TODO app</p>
    </div>
  )
}

export default Footer